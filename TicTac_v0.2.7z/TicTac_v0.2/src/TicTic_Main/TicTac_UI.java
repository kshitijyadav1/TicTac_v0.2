package TicTic_Main;
import java.awt.Color;
import static java.awt.Frame.NORMAL;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.event.*;
public class TicTac_UI extends javax.swing.JFrame {
    protected ImageIcon[] c = { 
			new ImageIcon("C:/Users/samsung/EclipseWorkSplash/JavaPractical/com.DataPackage/book/image/o.gif"), 
			new ImageIcon("C:/Users/samsung/EclipseWorkSplash/JavaPractical/com.DataPackage/book/image/x.gif") 
			};
    public static int control = 2;
    public static int total = 0;
    public static int winX = 0;
    public static int winO = 0;
    public static int draw = 0;
    public static boolean isInverse = false;
    /**
     * Creates new form TicTac_UI
     */
    
    public TicTac_UI() {
        initComponents();
                lblImga.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				
				if(control % 2 == 0) {
					setImg(lblImga, c[0]);	
				}
				if(control % 2 != 0) {
					setImg(lblImga, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImgb.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				

				if(control % 2 == 0) {
					setImg(lblImgb, c[0]);
					
				}
				if(control % 2 != 0) {
					setImg(lblImgb, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImgc.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				
				if(control % 2 == 0) {
					setImg(lblImgc, c[0]);
					
				}
				if(control % 2 != 0) {
					setImg(lblImgc, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImgd.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				

				if(control % 2 == 0) {
					setImg(lblImgd, c[0]);
					
				}
				if(control % 2 != 0) {
					setImg(lblImgd, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImge.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				
				if(control % 2 == 0) {
					setImg(lblImge, c[0]);
					
				}
				if(control % 2 != 0) {
					setImg(lblImge, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImgf.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				

				if(control % 2 == 0) {
					setImg(lblImgf, c[0]);
					
				}
				if(control % 2 != 0) {
					setImg(lblImgf, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImgg.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				

				if(control % 2 == 0) {
					setImg(lblImgg, c[0]);
					
				}
				if(control % 2 != 0) {
					setImg(lblImgg, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImgh.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inverse.setVisible(false);
				

				if(control % 2 == 0) {
					setImg(lblImgh, c[0]);
					
				}
				if(control % 2 != 0) {
					setImg(lblImgh, c[1]);
				}
				
				cheersUp();
			}
		});
		lblImgi.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				inverse.setVisible(false);
                                
				if(control % 2 == 0) {
					setImg(lblImgi, c[0]);
				}
				if(control % 2 != 0) {
					setImg(lblImgi, c[1]);
				}
				
				cheersUp();
			}
		});
		if(isAllImgFill()) {
			this.setVisible(false);
                }
               Oback.setForeground(Color.RED);
            Xback.setForeground(Color.BLUE);
    }
   
    
    public void cheersUp() {
		if(isXWin()) {
			JOptionPane.showMessageDialog(null, "Player X has won the game!", "Winner Cheerbox", JOptionPane.INFORMATION_MESSAGE);
			 winX += 1;
                        total += 1;
                        clearImg();
                       
		}
		else if(isOWin()) {
			JOptionPane.showMessageDialog(null, "Player O has won the game!", "Winner Cheerbox", JOptionPane.INFORMATION_MESSAGE);
			 winO += 1;
                        total += 1;
                        clearImg();
                       
		}
		else if(!(isXWin() && isOWin()) && isAllImgFill()) {
			JOptionPane.showMessageDialog(null, "Draw", "Winner Cheerbox", JOptionPane.INFORMATION_MESSAGE);
			total += 1;
                        draw += 1;
                        clearImg();
                        
		}
	}
	public void clearImg() {
		lblImga.setIcon(null);
		lblImgb.setIcon(null);
		lblImgc.setIcon(null);
		lblImgd.setIcon(null);
		lblImge.setIcon(null);
		lblImgf.setIcon(null);
		lblImgg.setIcon(null);
		lblImgh.setIcon(null);
		lblImgi.setIcon(null);
                control = 2;
               
               
                isInverse = false;
                inverse.setVisible(true);
                widTotal.setText(String.valueOf(total));
                totalXWin.setText(String.valueOf(winX));
                totalOWin.setText(String.valueOf(winO));
                totalDraw.setText(String.valueOf(draw));
                setMarkForeground();
	}
        public void addPLabel(JPanel panel, JLabel lblImg) {
		/* Add panel label */
		lblImg.setBorder(new LineBorder(Color.BLACK, 2));
		panel.add(lblImg);
		// =============**********++++++++++ //
	}
	public void setImg(JLabel lbl, ImageIcon icon) {
		//set image in jlabel
		lbl.setHorizontalAlignment(NORMAL);
		if(lbl.getIcon() == null) {
			lbl.setIcon(icon);
			control++;
                       
		}
       
		setMarkForeground();
		// =============**********++++++++++ //
	}
	
        public void setMarkForeground() {
             if(control % 2 == 0) {
            Oback.setForeground(Color.RED);
            Xback.setForeground(Color.BLUE);
        }
        if(control % 2 != 0) {
            Xback.setForeground(Color.RED);
            Oback.setForeground(Color.BLUE);
        }
        }
	
	
	//define condition method

	public boolean isOWin() {
		boolean answer = false;
		if(lblImga.getIcon() == c[0] && lblImgb.getIcon() == c[0] && lblImgc.getIcon() == c[0]) {
			answer = true;
		}
		if(lblImgd.getIcon() == c[0] && lblImge.getIcon() == c[0] && lblImgf.getIcon() == c[0]) {
			answer = true;
		}
		if(lblImgg.getIcon() == c[0] && lblImgh.getIcon() == c[0] && lblImgi.getIcon() == c[0]) {
			answer = true;
		}
		if(lblImga.getIcon() == c[0] && lblImgd.getIcon() == c[0] && lblImgg.getIcon() == c[0]) {
			answer = true;
		}
		if(lblImgb.getIcon() == c[0] && lblImge.getIcon() == c[0] && lblImgh.getIcon() == c[0]) {
			answer = true;
		}
		if(lblImgc.getIcon() == c[0] && lblImgf.getIcon() == c[0] && lblImgi.getIcon() == c[0]) {
			answer = true;
		}
		if(lblImga.getIcon() == c[0] && lblImge.getIcon() == c[0] && lblImgi.getIcon() == c[0]) {
			answer = true;
		}
		if(lblImgc.getIcon() == c[0] && lblImge.getIcon() == c[0] && lblImgg.getIcon() == c[0]) {
			answer = true;
		}
		return answer;
	}
	public boolean isXWin() {
		boolean answer = false;
		if(lblImga.getIcon() == c[1] && lblImgb.getIcon() == c[1] && lblImgc.getIcon() == c[1]) {
			answer = true;
		}
		if(lblImgd.getIcon() == c[1] && lblImge.getIcon() == c[1] && lblImgf.getIcon() == c[1]) {
			answer = true;
		}
		if(lblImgg.getIcon() == c[1] && lblImgh.getIcon() == c[1] && lblImgi.getIcon() == c[1]) {
			answer = true;
		}
		if(lblImga.getIcon() == c[1] && lblImgd.getIcon() == c[1] && lblImgg.getIcon() == c[1]) {
			answer = true;
		}
		if(lblImgb.getIcon() == c[1] && lblImge.getIcon() == c[1] && lblImgh.getIcon() == c[1]) {
			answer = true;
		}
		if(lblImgc.getIcon() == c[1] && lblImgf.getIcon() == c[1] && lblImgi.getIcon() == c[1]) {
			answer = true;
		}
		if(lblImga.getIcon() == c[1] && lblImge.getIcon() == c[1] && lblImgi.getIcon() == c[1]) {
			answer = true;
		}
		if(lblImgc.getIcon() == c[1] && lblImge.getIcon() == c[1] && lblImgg.getIcon() == c[1]) {
			answer = true;
		}
		return answer;
	}
	public boolean isAllImgFill() {
		boolean answer = false;
		if(lblImga.getIcon() != null && lblImgb.getIcon() != null && lblImgc.getIcon() != null
				&& lblImgd.getIcon() != null && lblImge.getIcon() != null && lblImgf.getIcon() != null
				&& lblImgg.getIcon() != null && lblImgh.getIcon() != null && lblImgi.getIcon() != null) {
			answer = true;
		}
		return answer;
	}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblImgb = new javax.swing.JLabel();
        lblImgc = new javax.swing.JLabel();
        lblImga = new javax.swing.JLabel();
        lblImgd = new javax.swing.JLabel();
        lblImge = new javax.swing.JLabel();
        lblImgf = new javax.swing.JLabel();
        lblImgg = new javax.swing.JLabel();
        lblImgh = new javax.swing.JLabel();
        lblImgi = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        inverse = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        widTotal = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        Oback = new javax.swing.JLabel();
        totalOWin = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        Xback = new javax.swing.JLabel();
        totalXWin = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        totalDraw = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tic Tac");
        setBackground(new java.awt.Color(102, 102, 102));
        setPreferredSize(new java.awt.Dimension(590, 380));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        lblImgb.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImgb.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImgc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImgc.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImga.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImga.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImgd.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImgd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImge.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImge.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImgf.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImgf.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImgg.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImgg.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImgh.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImgh.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblImgi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        lblImgi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblImga, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblImgb, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblImgc, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblImgd, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblImge, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblImgf, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblImgg, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblImgh, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblImgi, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImga, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblImgb, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblImgc, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImgd, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblImge, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblImgf, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImgg, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblImgh, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblImgi, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(153, 255, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 204));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Score Board");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 8, 220, 39));

        inverse.setBackground(new java.awt.Color(10, 10, 10));
        inverse.setForeground(new java.awt.Color(255, 255, 255));
        inverse.setText("Inverse");
        inverse.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        inverse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inverseActionPerformed(evt);
            }
        });
        jPanel2.add(inverse, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, -1, -1));

        jPanel4.setLayout(new java.awt.GridLayout(1, 0));

        jLabel16.setFont(new java.awt.Font("Leelawadee", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 255));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Total : ");
        jLabel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel4.add(jLabel16);

        widTotal.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        widTotal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        widTotal.setText("0");
        widTotal.setToolTipText("");
        widTotal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 255), 2));
        jPanel4.add(widTotal);

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 53, 210, -1));

        jPanel5.setPreferredSize(new java.awt.Dimension(163, 47));
        jPanel5.setLayout(new java.awt.GridLayout());

        Oback.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        Oback.setForeground(new java.awt.Color(0, 0, 255));
        Oback.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Oback.setText("O");
        Oback.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        Oback.setMaximumSize(new java.awt.Dimension(39, 44));
        Oback.setMinimumSize(new java.awt.Dimension(39, 44));
        jPanel5.add(Oback);

        totalOWin.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        totalOWin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalOWin.setText("0");
        totalOWin.setToolTipText("");
        totalOWin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 255), 2));
        jPanel5.add(totalOWin);

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 87, 210, 35));

        jPanel6.setPreferredSize(new java.awt.Dimension(163, 47));
        jPanel6.setLayout(new java.awt.GridLayout());

        Xback.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        Xback.setForeground(new java.awt.Color(0, 0, 255));
        Xback.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Xback.setText("X");
        Xback.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel6.add(Xback);

        totalXWin.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        totalXWin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalXWin.setText("0");
        totalXWin.setToolTipText("");
        totalXWin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 255), 2));
        jPanel6.add(totalXWin);

        jPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 128, 210, 30));

        jPanel7.setPreferredSize(new java.awt.Dimension(163, 47));
        jPanel7.setLayout(new java.awt.GridLayout(1, 0));

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Draw : ");
        jLabel10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel7.add(jLabel10);

        totalDraw.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        totalDraw.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalDraw.setText("0");
        totalDraw.setToolTipText("");
        totalDraw.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 255), 2));
        jPanel7.add(totalDraw);

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 166, 210, 35));

        jButton2.setBackground(new java.awt.Color(10, 10, 10));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Reset");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        jPanel3.setBackground(new java.awt.Color(153, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel3.setPreferredSize(new java.awt.Dimension(150, 160));

        jLabel5.setFont(new java.awt.Font("Copperplate Gothic Bold", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 51, 51));
        jLabel5.setText("Tic");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/TICTACTOE.gif"))); // NOI18N
        jLabel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabel9.setFont(new java.awt.Font("Copperplate Gothic Bold", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 0, 255));
        jLabel9.setText("Tac");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void inverseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inverseActionPerformed
        isInverse = true;
        inverse.setVisible(false);
        if(isInverse) {
            control += 1;
           Xback.setForeground(Color.RED);
            Oback.setForeground(Color.BLUE);
         }
        else {
            control = 2;
             Oback.setForeground(Color.RED);
            Xback.setForeground(Color.BLUE);
        }
        
    }//GEN-LAST:event_inverseActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

         total = 0;
         winX = 0;
         winO = 0;
         draw = 0;
         totalDraw.setText(String.valueOf(draw));
         totalOWin.setText(String.valueOf(winO));
         totalXWin.setText(String.valueOf(winX));
         widTotal.setText(String.valueOf(total));
    }//GEN-LAST:event_jButton2ActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
		
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TicTac_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TicTac_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TicTac_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TicTac_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TicTac_UI ticTac = new TicTac_UI();
                ticTac.setVisible(true);
                ticTac.setSize(605, 380);
                ticTac.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\samsung\\Documents\\NetBeansProjects\\TicTac_v0.2\\src\\images\\TICTACTOE.gif");
                ticTac.setIconImage(icon);
            }
        });
        
    }
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Oback;
    private javax.swing.JLabel Xback;
    private javax.swing.JButton inverse;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JLabel lblImga;
    private javax.swing.JLabel lblImgb;
    private javax.swing.JLabel lblImgc;
    private javax.swing.JLabel lblImgd;
    private javax.swing.JLabel lblImge;
    private javax.swing.JLabel lblImgf;
    private javax.swing.JLabel lblImgg;
    private javax.swing.JLabel lblImgh;
    private javax.swing.JLabel lblImgi;
    private javax.swing.JLabel totalDraw;
    private javax.swing.JLabel totalOWin;
    private javax.swing.JLabel totalXWin;
    private javax.swing.JLabel widTotal;
    // End of variables declaration//GEN-END:variables
}
